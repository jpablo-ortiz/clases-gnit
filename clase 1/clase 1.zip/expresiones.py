# Expresiones
# 1. Aritméticas
# 2. Lógicas
# 3. Relacionales

# 1. Aritméticas
# +, -, *, /, % (Módulo).

numero = 4 + 2 * 6 / 4 + 3 + 6 * 6 / 5 - 3
print(numero)

# 2. Lógicas
# and, or, not -> y, o, no

A = True
B = False

print(not A or not B)